package com.thecuriouscat.myecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEcommerceApplication.class, args);
	}

}
